
Reggen12.zip -- November 2004

This zip file contains the following files:
  Readme.txt:  This file.
  RegGen.exe:  Executable version of the program.
  RegGen.pdf:  PDF version of documentation.
  RegGen.htm:  HTML version of documentation.
  Readme.2  :  Information on how to read documentation in different formats.
  RegGen.smp:  A sample parameters file.

Installation:
-------------
No special installation is needed.  Just copy RegGen.exe
into any directory in the DOS path, and it will run under DOS.

Registration and Support:
------------------------
This is freeware.  If you find it useful, please tell me so:
   Prof Jeff Miller
   Department of Psychology
   Univ of Otago
   Dunedin, New Zealand
   email: miller@psy.otago.ac.nz
Also, you can send me questions and bug reports, and I will
respond to them as I find the time.
