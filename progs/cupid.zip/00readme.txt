This file has 3 parts:

1. What is Cupid? A brief introduction.
2. How to install and run Cupid the first time.
3. Instructions for a short demo that you can use
   to get the feel for Cupid when you first run it.

**************** Part 1. What is Cupid? A brief introduction.

CUPID is a free Windows program for doing Computations with Univariate
Probability Distributions. It is primarily designed for exploring probability
distributions and stochastic models, although it does have some possible uses
in data analysis as well.

For any recognized probability distribution (see below), Cupid can:
 o Compute moments: mean, median, variance, skewness, etc
 o Compute and plot functions: PDF, CDF, hazard function,
   and moment-generating function.
 o Compute percentile values.
 o Compute the Ln(Likelihood) of a set of data values.
 o Generate random numbers.
 o Compute parameter estimates that produce certain desired moments
   or percentiles, or that maximize the likelihood of a given data set.
 o et cetera.

Cupid knows many standard probability distributions, including the Beta,
Binomial, Cauchy, Chi, Chi-Square, Cosine, Ex-Gaussian, Exponential,
Extreme-Value, Ex-Wald, F, Gamma, Generalized-Error, Geometric,
Hyperbolic-Tangent, Laplace, Logistic, Log-Normal, Naka-Rushton,
Negative-Binomial, Neyman-A, Noncentral-F, Normal, Pareto, Poisson, Quantal,
Quick, r, Rayleigh, Studentized-Range, t, Triangular, Uniform, VonMises, Wald,
and Weibull. Perhaps more interestingly, Cupid can form new "derived"
distributions from these standard distributions by convolution, mixturing,
truncation, formulation of an order statistic, and various transformations
(linear, power, etc). All of the same computations can then be performed with
such derived distributions (including making further derived distributions).

**************** Part 2. How to install and run Cupid the first time.

1. Unzip the distribution file CUPIDnnn.ZIP.

2. Start the program Cupid.exe by double-clicking on it or by typing CUPID<enter>
at a command prompt.

**************** Part 3. Instructions for a short Cupid demo.

o Start the program Cupid.exe.

o Note that it says Normal(0,1) at the top.  That means you are currently
  working with a Normal distribution having mean 0 & standard deviation 1.

o Cupid's prompt for you to enter commands is the ">"

o Cupid is not case-sensitive, but below I've capitalized the stuff that
  you are supposed to type for this demo.

o Type MEAN and then return/enter.  Cupid tells you the mean of the current
  distribution is 0.  Wait...there's more.

o Type:  PDF(0) CDF(1.69) INVERSECDF(0.99)   (all on one line, or separate lines)
  Cupid will print each of the values.  Voila, you have normal tables online.

o Change to another distribution just by typing it's name and parameters.
  For example, type:  F(1,98)
  Now you are working with an F distribution having 1 & 98 degrees of freedom.
  Type:  INVERSECDF(0.95)
  Voila, you have F-tables online.

o Change to a uniform distribution by typing: UNIFORM(0,1)
  Find out which uniform distribution has mean 10 and variance 100 by
  typing ESTFROMMOMENTS(10,100).  Cupid adjusts the parameters of the
  uniform to give you these desired mean and variance values.  The new
  distribution with these adjusted parameters is Uniform(-7.321,27.32).

o Let's look at a more complicated distribution:
  Type: ORDERIID(2,10,NORMAL(0,1))
  You have just told Cupid to work with the distribution of the
  2nd order statistic in a sample of 10 independent, identically
  distributed (IID) standard normals.
  Type: PLOT(PDF) to get a look at its PDF.
  Type: MEAN SD SKEWNESS to get some of its parameters.

o What distributions does CUPID know about?  For a full list, type
  SHOW(DISTRIBUTIONS)
  For a full list of functions that it can compute, type:
  SHOW(FUNCTIONS)
  For a full list of program control commands, type:
  SHOW(COMMANDS)

o Type HELP to see the rest of Cupid's pathetic online help.  The real
  documentation is in the file CUPID.pdf.
  
o So much for the user interface.  Play around with it.  You can do a lot
  without the documentation.  But there are lots of features that you would
  probably not expect if you never look in the docs.

o When you want to quit, use this command:
  STOP
