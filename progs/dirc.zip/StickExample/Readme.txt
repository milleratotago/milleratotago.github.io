
         Using a Memory Stick to Synchronize Two Machines

This directory shows a detailed step-by-step example of how to set up a
memory stick to keep certain directories of two different machines synchronized.
It is a little fussy to set up the first time, but extremely convenient once
that is done.  After initial setup, all you do is to run two batch files--one
is run when you leave a machine (to copy new files from the machine onto the
stick), and one is run when you arrive at a machine (to copy new files from the
stick onto the machine).

Initial setup steps:

1. Copy the included files StOld.Bat, StNew.Bat, dirc.exe and chooserr.exe to
the memory stick.

2. Check that each computer has the environment variable %ComputerName%
defined. You can check and if necessary set this variable via
  Start button -> Settings -> Control Panel -> System -> tab for Computer Name
For the rest of this example, I will assume that you are using the stick
with two computers whose computernames are HOME and OFFICE. These names
influence _only_ the names of the directory specification files described
in steps 3 and 4.

Note: In steps 3a, 3b, 4a, and 4b you create four plain text files
(eg using Notepad). These files should be made on the memory stick,
in the same directory as StOld.Bat and StNew.Bat. These files are called
HOME and OFFICE in these instructions, but the actual file names should
match the %ComputerName% settings of the two machines you are trying
to keep in synch.

3a. Create a plain text file called HOME on the stick. Be sure there is no .txt
extension on the file name. This file is used to designate the directories on
the HOME machine that you want to keep synch'ed with corresponding directories
on the OFFICE MACHINE.

This HOME file has two columns, separated by a TAB. The first column
is a [Dir1]FileSet1 specification, and it indicates a set of files _on the
stick_ that are to be included in the synchronization protocol. (Don't worry if
there are no files on the stick initially; they will be copied to the stick the
first time you run StOld.) The second column indicates the corresponding
directory on the HOME computer where those to-be-synchronized files live.  For
example, the HOME file might include these two tab-separated columns:
Docs\*.doc	C:\Documents and Settings\admin
In Progress\*.*	C:\In Progress
Downloads\*.*	C:\Downloads
With these specifications, the synchronization protocol will include all of the
*.doc files in C:\Documents and Settings\Jeff and its subdirectories, all files
in C:\In Progress, and all files in C:\Downloads.

3b. Create another plain text file called HOME_NoR (no .txt) on the stick. This
file is used to designate the directories to be synch'ed (NOT including their
subdirectories). This file's format is parallel to that of HOME, except that
here you specify a new set of directories that will be kept synched but NOT
recursively including subdirectories.  For example, this file might include
these two tab-separated columns:
Data\*.*	C:\Data
With these specifications, the synchronization protocol will include all of the
files in C:\Data but will NOT recurse to its subdirectories.

4a. Create a plain text file called OFFICE (no .txt) on the stick to specify
the directories on the OFFICE machine that are to be kept synch'ed with
those on the HOME machine. The format is the same as that of the HOME file.
In fact, the first column of this file is identical to the first column of the
HOME file, but the second may be different. Specifically, the second column
indicates the corresponding directories on the OFFICE computer.  For example,
the file might include these two tab-separated columns:
Docs\*.doc	D:\Documents and Settings\Jeff
In Progress\*.*	D:\In Progress
Downloads\*.*	D:\Downloads
The differences between the second columns of this file and the HOME file
allow for the possibility of differences in disk drives or directory
structures between the two machines.

4b. Create a plain text file called OFFICE_NoR (no .txt) parallel to HOME_NoR.
For example:
Data\*.*	L:\System\Data

5. Finally, create on the stick all of the directories referenced in the HOME
and HOME_NoR files. For the examples shown, you would have to create the four
directories "Docs", "In Progress", "Downloads", and "Data". These directories
should be created in the same directory with StOld.Bat and StNew.Bat,
possibly at the root of the memory stick.

Setup is done!

Day to day synchronization:

Now that the setup is complete, the batch files StOld and StNew do all the
work.  When you want to update the memory stick with the new files on the
current computer (i.e., the stick is "old"), you just run StOld (e.g., by
double clicking on it). When you want to update the current computer with the
new files from the memory stick (i.e., the stick is "new"), you just run StNew.

When you run StOld or StNew, the batch file first performs a safety check.
Specifically, it lists files in the supposedly older directories that are not
present in the supposedly newer directories. These "extra" files are presumably
files that you deleted and no longer want, so you want to delete them during
the update process, but the listing here is just to give you one last reminder
of what is going to happen. After these extra files have been listed, you are
given these options:
    REM Choose:
    REM   0 : Continue with deletes
    REM   1 : Skip deletes
    REM   2 : Abort
    Choose 0->2
If you choose 0, the update will proceed, and the "extra" files will be deleted.
If you choose 1, the update will proceed, but the "extra" files will not be deleted.
If you choose 2, the update will abort.
