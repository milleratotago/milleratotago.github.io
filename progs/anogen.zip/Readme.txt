
Anogen14.zip -- November 2004

This zip file contains the following files:
  Anogen.exe:  Executable version of the program.
  Readme.txt:  This file.
  Readme.2  :  Information on how to read documentation in different formats.
  Teacher.pdf: PDF version of documentation for teachers.
  Student.pdf: PDF version of documentation for students.

Installation:
-------------
No special installation is needed.  Just copy Anogen.exe into any directory in
the path and it should run under Windows 98, ME, 2000, XP, etc.

Documentation:
--------------
There are separate teacher and student versions of the documentation in
PDF files.  The Teacher version contains all of the information in the
student version, please lots more.

Registration and Support:
------------------------
This is freeware.  If you find it useful, please tell me so:
   Prof Jeff Miller
   Department of Psychology
   Univ of Otago
   Dunedin, New Zealand
   email: miller@psy.otago.ac.nz
Also, you can send me questions, bug reports, and suggestions, and I will
respond to them as I find the time.
